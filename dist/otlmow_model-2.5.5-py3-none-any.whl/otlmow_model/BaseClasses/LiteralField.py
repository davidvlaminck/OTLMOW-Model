﻿from otlmow_model.Datatypes import StringField


class LiteralField(StringField):
    pass