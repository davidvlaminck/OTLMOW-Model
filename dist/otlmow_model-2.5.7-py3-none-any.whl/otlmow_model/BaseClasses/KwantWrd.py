﻿class KwantWrd:
    eenheid = None