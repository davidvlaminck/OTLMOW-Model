class GeenGeometrie:
    pass
