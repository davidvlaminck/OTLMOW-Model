import sys
import os

# Voeg het projectpad toe aan sys.path zodat absolute imports werken in unittests
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../..')))

import random
import warnings
from datetime import time, datetime, date, timezone
from typing import Any

from .OTLField import OTLField
from ..Exceptions.CouldNotConvertToCorrectTypeError import CouldNotConvertToCorrectTypeError
from ..warnings.IncorrectTypeWarning import IncorrectTypeWarning


class TimeField(OTLField):
    """Beschrijft een tekstregel volgens http://www.w3.org/2001/XMLSchema#string."""

    naam = 'Time'
    objectUri = 'http://www.w3.org/2001/XMLSchema#time'
    definition = 'Beschrijft een datum volgens http://www.w3.org/2001/XMLSchema#time.'
    label = 'Tijd'
    usagenote = 'https://www.w3.org/TR/xmlschema-2/#time'
    clearing_value = '88888888'
    native_type = time

    @classmethod
    def convert_to_correct_type(cls, value: Any, log_warnings: bool = True) -> time | None:
        if value is None:
            return None
        if isinstance(value, time):
            return value
        if isinstance(value, bool):
            raise CouldNotConvertToCorrectTypeError(
                f'{value} could not be converted to correct type (implied by {cls.__name__})'
            )
        return cls._convert_non_time(value, log_warnings)

    @classmethod
    def _convert_non_time(cls, value: Any, log_warnings: bool) -> time:
        if isinstance(value, datetime):
            return cls._convert_datetime(value, log_warnings)
        if isinstance(value, date):
            return cls._convert_date(log_warnings)
        if isinstance(value, int):
            return cls._convert_int(value, log_warnings)
        if isinstance(value, str):
            return cls._convert_string(value, log_warnings)
        return cls._convert_fallback(value)

    @classmethod
    def _convert_datetime(cls, value: datetime, log_warnings: bool) -> time:
        if log_warnings:
            warnings.warn(
                category=IncorrectTypeWarning,
                message='Assigned a datetime to a time datatype. '
                'Automatically converted to the correct type. Please change the type',
            )
        return time(value.hour, value.minute, value.second)

    @classmethod
    def _convert_date(cls, log_warnings: bool) -> time:
        if log_warnings:
            warnings.warn(
                category=IncorrectTypeWarning,
                message='Assigned a date to a time datatype. '
                'Automatically converted to the correct type. Please change the type',
            )
        return time()

    @classmethod
    def _convert_int(cls, value: int, log_warnings: bool) -> time:
        if log_warnings:
            warnings.warn(
                category=IncorrectTypeWarning,
                message='Assigned an integer to a time datatype. '
                'Automatically converted to the correct type. Please change the type',
            )
        timestamp = datetime.fromtimestamp(value, timezone.utc)
        return time(timestamp.hour, timestamp.minute, timestamp.second)

    @classmethod
    def _convert_string(cls, value: str, log_warnings: bool) -> time:
        try:
            dt = datetime.strptime(value, '%H:%M:%S')
        except ValueError:
            try:
                dt = datetime.strptime(value, '%Y-%m-%d %H:%M:%S')
            except ValueError:
                try:
                    dt = datetime.strptime(value, '%d/%m/%Y %H:%M:%S')
                except Exception as e:
                    raise CouldNotConvertToCorrectTypeError(
                        f'{value} could not be converted to correct type (implied by {cls.__name__})'
                    ) from e
        if log_warnings:
            warnings.warn(
                category=IncorrectTypeWarning,
                message='Assigned a string to a time datatype. '
                'Automatically converted to the correct type. Please change the type',
            )
        return time(dt.hour, dt.minute, dt.second)

    @classmethod
    def _convert_fallback(cls, value: Any) -> time:
        raise CouldNotConvertToCorrectTypeError(
            f'{value} could not be converted to correct type (implied by {cls.__name__})'
        )

    @classmethod
    def validate(cls, value: Any, attribuut) -> bool:
        if value is not None and not isinstance(value, time):
            raise TypeError(f'expecting datetime in {attribuut.naam}')
        return True

    @classmethod
    def value_default(cls, value: time) -> str | None:
        return None if value is None else value.strftime('%H:%M:%S')

    def __str__(self) -> str:
        return OTLField.__str__(self)

    @classmethod
    def create_dummy_data(cls) -> time:
        return time(hour=random.randint(0, 23), minute=random.randint(0, 59), second=random.randint(0, 59))
