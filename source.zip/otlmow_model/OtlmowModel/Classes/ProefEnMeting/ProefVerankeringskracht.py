# coding=utf-8
from ...BaseClasses.OTLObject import OTLAttribuut
from ...Classes.Abstracten.Proef import Proef
from ...Datatypes.DtcDocument import DtcDocument, DtcDocumentWaarden
from ...GeometrieTypes.PuntGeometrie import PuntGeometrie
from ...GeometrieTypes.LijnGeometrie import LijnGeometrie
from ...GeometrieTypes.VlakGeometrie import VlakGeometrie


# Generated with OTLClassCreator. To modify: extend, do not edit
class ProefVerankeringskracht(Proef, PuntGeometrie, LijnGeometrie, VlakGeometrie):
    """Een trekproef in situ om de verankering van de ankerstaven in een betonverharding te testen."""

    typeURI = 'https://wegenenverkeer.data.vlaanderen.be/ns/proefenmeting#ProefVerankeringskracht'
    """De URI van het object volgens https://www.w3.org/2001/XMLSchema#anyURI."""

    def __init__(self):
        super().__init__()

        self.add_valid_relation(relation='https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#IsInspectieVan', target='https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Cementbetonverharding', direction='o')  # o = direction: outgoing

        self._verankeringskracht = OTLAttribuut(field=DtcDocument,
                                                naam='verankeringskracht',
                                                label='verankeringskracht',
                                                objectUri='https://wegenenverkeer.data.vlaanderen.be/ns/proefenmeting#ProefVerankeringskracht.verankeringskracht',
                                                definition='Het resultaat van de test om de verankeringskracht in de BV laag.',
                                                owner=self)

    @property
    def verankeringskracht(self) -> DtcDocumentWaarden:
        """Het resultaat van de test om de verankeringskracht in de BV laag."""
        return self._verankeringskracht.get_waarde()

    @verankeringskracht.setter
    def verankeringskracht(self, value):
        self._verankeringskracht.set_waarde(value, owner=self)
