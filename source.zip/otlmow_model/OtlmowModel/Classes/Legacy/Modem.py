# coding=utf-8
from ...BaseClasses.LegacyObject import LegacyObject


# Generated with LegacyClassCreator. To modify: extend, do not edit
class Modem(LegacyObject):
    """Modem (Legacy)
	MODEM"""

    typeURI = 'https://lgc.data.wegenenverkeer.be/ns/installatie#Modem'
    """De URI van het object volgens https://www.w3.org/2001/XMLSchema#anyURI."""

    def __init__(self):
        super().__init__()
