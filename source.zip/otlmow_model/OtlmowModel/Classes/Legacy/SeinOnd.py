# coding=utf-8
from ...BaseClasses.LegacyObject import LegacyObject


# Generated with LegacyClassCreator. To modify: extend, do not edit
class SeinOnd(LegacyObject):
    """Onderdoorvaartsein (Legacy)
	Onderdoorvaartsein"""

    typeURI = 'https://lgc.data.wegenenverkeer.be/ns/installatie#SeinOnd'
    """De URI van het object volgens https://www.w3.org/2001/XMLSchema#anyURI."""

    def __init__(self):
        super().__init__()
