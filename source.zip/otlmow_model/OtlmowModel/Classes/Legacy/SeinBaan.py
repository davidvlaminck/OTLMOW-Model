# coding=utf-8
from ...BaseClasses.LegacyObject import LegacyObject


# Generated with LegacyClassCreator. To modify: extend, do not edit
class SeinBaan(LegacyObject):
    """Baansein (Legacy)
	Baansein"""

    typeURI = 'https://lgc.data.wegenenverkeer.be/ns/installatie#SeinBaan'
    """De URI van het object volgens https://www.w3.org/2001/XMLSchema#anyURI."""

    def __init__(self):
        super().__init__()
