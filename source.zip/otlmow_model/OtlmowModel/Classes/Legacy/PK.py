# coding=utf-8
from ...BaseClasses.LegacyObject import LegacyObject


# Generated with LegacyClassCreator. To modify: extend, do not edit
class PK(LegacyObject):
    """Pijl-kruis bord (Legacy)
	Dynamische borden : Pijl-kruis bord (def. SB 270 hfdst 50)"""

    typeURI = 'https://lgc.data.wegenenverkeer.be/ns/installatie#PK'
    """De URI van het object volgens https://www.w3.org/2001/XMLSchema#anyURI."""

    def __init__(self):
        super().__init__()
