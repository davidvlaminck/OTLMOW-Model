# coding=utf-8
from ...BaseClasses.LegacyObject import LegacyObject


# Generated with LegacyClassCreator. To modify: extend, do not edit
class ADR(LegacyObject):
    """ADR camera (Legacy)
	ADR Camera"""

    typeURI = 'https://lgc.data.wegenenverkeer.be/ns/installatie#ADR'
    """De URI van het object volgens https://www.w3.org/2001/XMLSchema#anyURI."""

    def __init__(self):
        super().__init__()
