# coding=utf-8
from ...BaseClasses.LegacyObject import LegacyObject


# Generated with LegacyClassCreator. To modify: extend, do not edit
class Com(LegacyObject):
    """Communicatie meetstation VMM (Legacy)
	VMM lucht : infrastructuur ivm communicatie meetstation luchtkwaliteit VMM"""

    typeURI = 'https://lgc.data.wegenenverkeer.be/ns/installatie#Com'
    """De URI van het object volgens https://www.w3.org/2001/XMLSchema#anyURI."""

    def __init__(self):
        super().__init__()
