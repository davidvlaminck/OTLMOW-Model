# coding=utf-8
from ...BaseClasses.LegacyObject import LegacyObject


# Generated with LegacyClassCreator. To modify: extend, do not edit
class TWeg(LegacyObject):
    """Toeristische weg (Legacy)
	Wegen : T-weg - Toeristische of recreatieve weg"""

    typeURI = 'https://lgc.data.wegenenverkeer.be/ns/installatie#TWeg'
    """De URI van het object volgens https://www.w3.org/2001/XMLSchema#anyURI."""

    def __init__(self):
        super().__init__()
