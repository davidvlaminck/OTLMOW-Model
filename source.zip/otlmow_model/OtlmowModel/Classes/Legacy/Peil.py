# coding=utf-8
from ...BaseClasses.LegacyObject import LegacyObject


# Generated with LegacyClassCreator. To modify: extend, do not edit
class Peil(LegacyObject):
    """Peilmeetinstallatie (Legacy)
	Water : Peilmeetinstallatie (omvat één of meerdere peilmeters en alle locaal opgestelde apparatuur mee te onderhouden door aannemer peilmeetinstallatie)"""

    typeURI = 'https://lgc.data.wegenenverkeer.be/ns/installatie#Peil'
    """De URI van het object volgens https://www.w3.org/2001/XMLSchema#anyURI."""

    def __init__(self):
        super().__init__()
