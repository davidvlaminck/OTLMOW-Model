# coding=utf-8
from ...BaseClasses.LegacyObject import LegacyObject


# Generated with LegacyClassCreator. To modify: extend, do not edit
class RISLegacy(LegacyObject):
    """Beveiligingsinstallatie RIS (Legacy)
	BIB-,BRAND-,INBRAAK- TOEGANGS-,INSTALLATIEBEVEILIGING (deel waarvoor het RIS dient tussen te komen)"""

    typeURI = 'https://lgc.data.wegenenverkeer.be/ns/installatie#RIS'
    """De URI van het object volgens https://www.w3.org/2001/XMLSchema#anyURI."""

    def __init__(self):
        super().__init__()
