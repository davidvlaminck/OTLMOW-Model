# coding=utf-8
from typing import ClassVar

from ...BaseClasses.BooleanField import BooleanField
from ...BaseClasses.IntegerField import IntegerField
from ...BaseClasses.OTLObject import OTLAttribuut
from ...BaseClasses.StringField import StringField
from ...Classes.Abstracten.TechnischDocument import TechnischDocument
from ...Classes.ImplementatieElement.AIMNaamObject import AIMNaamObject
from ...Datatypes.KlTypeBevestigingRail import KlTypeBevestigingRail
from ...Datatypes.KlTypeKlem import KlTypeKlem
from ...GeometrieTypes.PuntGeometrie import PuntGeometrie


# Generated with OTLClassCreator. To modify: extend, do not edit
class Railconstructie(TechnischDocument, AIMNaamObject, PuntGeometrie):
    """Geheel bestaande uit een doorlopend profiel waarop of waartegen iets rijdt of glijdt, samen met de klemmen, tussenplaten en ondersteuningsprofielen die het profiel bevestigen en ondersteunen."""

    typeURI = 'https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Railconstructie'
    """De URI van het object volgens https://www.w3.org/2001/XMLSchema#anyURI."""

    _VALID_RELATIONS: ClassVar[list[tuple[str, str, str, str | None]]] = [
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Bevestiging', 'https://wegenenverkeer.data.vlaanderen.be/ns/abstracten#ConstructieElementSluisStuw', 'u', None),  # u = unidirectional
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Bevestiging', 'https://wegenenverkeer.data.vlaanderen.be/ns/installatie#Balk', 'u', None),  # u = unidirectional
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Bevestiging', 'https://wegenenverkeer.data.vlaanderen.be/ns/installatie#DraagstructuurBWCTWC', 'u', None),  # u = unidirectional
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Bevestiging', 'https://wegenenverkeer.data.vlaanderen.be/ns/installatie#HorizontaleConstructieplaat', 'u', None),  # u = unidirectional
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Bevestiging', 'https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Portiek', 'u', None),  # u = unidirectional
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#HoortBij', 'https://wegenenverkeer.data.vlaanderen.be/ns/installatie#Bovenrolwagen', 'o', None),  # o = direction: outgoing
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#HoortBij', 'https://wegenenverkeer.data.vlaanderen.be/ns/installatie#Glijgeleiding', 'o', None),  # o = direction: outgoing
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#HoortBij', 'https://wegenenverkeer.data.vlaanderen.be/ns/installatie#HijsEnHefwerktuig', 'o', None),  # o = direction: outgoing
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#HoortBij', 'https://wegenenverkeer.data.vlaanderen.be/ns/installatie#Onderrolwagen', 'o', None),  # o = direction: outgoing
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#HoortBij', 'https://wegenenverkeer.data.vlaanderen.be/ns/installatie#Rolgeleiding', 'o', None),  # o = direction: outgoing
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#LigtOp', 'https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Glijmateriaal', 'i', None),  # i = direction: incoming
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#LigtOp', 'https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Loopprofiel', 'i', None),  # i = direction: incoming
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#LigtOp', 'https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Rol', 'i', None),  # i = direction: incoming
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#LigtOp', 'https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Wiel', 'i', None),  # i = direction: incoming
    ]

    def __init__(self):
        super().__init__()

        self.add_valid_relations(self._VALID_RELATIONS)

        self._aantalVoegen = OTLAttribuut(field=IntegerField,
                                          naam='aantalVoegen',
                                          label='aantal voegen',
                                          objectUri='https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Railconstructie.aantalVoegen',
                                          definition='Het aantal voegen.',
                                          owner=self)

        self._heeftLangsblokkeringrail = OTLAttribuut(field=BooleanField,
                                                      naam='heeftLangsblokkeringrail',
                                                      label='heeft langsblokkeringrail',
                                                      objectUri='https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Railconstructie.heeftLangsblokkeringrail',
                                                      definition='Geeft aan of de rail langsblokkeringrail heeft of niet.',
                                                      owner=self)

        self._heeftOnderlegmat = OTLAttribuut(field=BooleanField,
                                              naam='heeftOnderlegmat',
                                              label='heeft onderlegmat',
                                              objectUri='https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Railconstructie.heeftOnderlegmat',
                                              definition='Geeft aan of de railconstructie een onderlegmat heeft.',
                                              owner=self)

        self._heeftTussenplaat = OTLAttribuut(field=BooleanField,
                                              naam='heeftTussenplaat',
                                              label='heeft tussenplaat',
                                              objectUri='https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Railconstructie.heeftTussenplaat',
                                              definition='Geeft aan of de railconstructie een tussenplaat heeft.',
                                              owner=self)

        self._heeftVoegen = OTLAttribuut(field=BooleanField,
                                         naam='heeftVoegen',
                                         label='heeft voegen',
                                         objectUri='https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Railconstructie.heeftVoegen',
                                         definition='Geeft aan of de bovenrolwagen voegen heeft of niet.',
                                         owner=self)

        self._klemtype = OTLAttribuut(field=KlTypeKlem,
                                      naam='klemtype',
                                      label='klemtype',
                                      objectUri='https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Railconstructie.klemtype',
                                      definition='Het type klem gebruikt in de railconstructie.',
                                      owner=self)

        self._typeBevestiging = OTLAttribuut(field=KlTypeBevestigingRail,
                                             naam='typeBevestiging',
                                             label='type bevestiging rail',
                                             objectUri='https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Railconstructie.typeBevestiging',
                                             definition='Het type bevestiging van een rail.',
                                             owner=self)

        self._typeKlem = OTLAttribuut(field=StringField,
                                      naam='typeKlem',
                                      label='type klem',
                                      objectUri='https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Railconstructie.typeKlem',
                                      usagenote='Attribuut uit gebruik sinds versie 2.20.0 ',
                                      deprecated_version='2.20.0',
                                      definition='Het type klem gebruikt in de railconstructie.',
                                      owner=self)

    @property
    def aantalVoegen(self) -> int:
        """Het aantal voegen."""
        return self._aantalVoegen.get_waarde()

    @aantalVoegen.setter
    def aantalVoegen(self, value):
        self._aantalVoegen.set_waarde(value, owner=self)

    @property
    def heeftLangsblokkeringrail(self) -> bool:
        """Geeft aan of de rail langsblokkeringrail heeft of niet."""
        return self._heeftLangsblokkeringrail.get_waarde()

    @heeftLangsblokkeringrail.setter
    def heeftLangsblokkeringrail(self, value):
        self._heeftLangsblokkeringrail.set_waarde(value, owner=self)

    @property
    def heeftOnderlegmat(self) -> bool:
        """Geeft aan of de railconstructie een onderlegmat heeft."""
        return self._heeftOnderlegmat.get_waarde()

    @heeftOnderlegmat.setter
    def heeftOnderlegmat(self, value):
        self._heeftOnderlegmat.set_waarde(value, owner=self)

    @property
    def heeftTussenplaat(self) -> bool:
        """Geeft aan of de railconstructie een tussenplaat heeft."""
        return self._heeftTussenplaat.get_waarde()

    @heeftTussenplaat.setter
    def heeftTussenplaat(self, value):
        self._heeftTussenplaat.set_waarde(value, owner=self)

    @property
    def heeftVoegen(self) -> bool:
        """Geeft aan of de bovenrolwagen voegen heeft of niet."""
        return self._heeftVoegen.get_waarde()

    @heeftVoegen.setter
    def heeftVoegen(self, value):
        self._heeftVoegen.set_waarde(value, owner=self)

    @property
    def klemtype(self) -> str:
        """Het type klem gebruikt in de railconstructie."""
        return self._klemtype.get_waarde()

    @klemtype.setter
    def klemtype(self, value):
        self._klemtype.set_waarde(value, owner=self)

    @property
    def typeBevestiging(self) -> str:
        """Het type bevestiging van een rail."""
        return self._typeBevestiging.get_waarde()

    @typeBevestiging.setter
    def typeBevestiging(self, value):
        self._typeBevestiging.set_waarde(value, owner=self)

    @property
    def typeKlem(self) -> str:
        """Het type klem gebruikt in de railconstructie."""
        return self._typeKlem.get_waarde()

    @typeKlem.setter
    def typeKlem(self, value):
        self._typeKlem.set_waarde(value, owner=self)
