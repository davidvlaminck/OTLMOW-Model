# coding=utf-8
from ...Classes.Onderdeel.OpgaandeHoutigeVegetatie import OpgaandeHoutigeVegetatie


# Generated with OTLClassCreator. To modify: extend, do not edit
class Wilgenstruweel(OpgaandeHoutigeVegetatie):
    """H1 - wilgensoorten, sporkehout, gewone vlier, braam spp., brede stekelvaren, grote brandnetel, hondsdraf, kleefkruid, pitrus."""

    typeURI = 'https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Wilgenstruweel'
    """De URI van het object volgens https://www.w3.org/2001/XMLSchema#anyURI."""

    def __init__(self):
        super().__init__()
