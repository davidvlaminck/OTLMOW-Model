# coding=utf-8
from typing import ClassVar

from ...BaseClasses.OTLObject import OTLAttribuut
from ...Classes.Abstracten.SerienummerObject import SerienummerObject
from ...Classes.ImplementatieElement.AIMNaamObject import AIMNaamObject
from ...Datatypes.KlElastischElementHardheid import KlElastischElementHardheid
from ...Datatypes.KlElastischElementMateriaal import KlElastischElementMateriaal
from ...GeometrieTypes.PuntGeometrie import PuntGeometrie


# Generated with OTLClassCreator. To modify: extend, do not edit
class ElastischElement(SerienummerObject, AIMNaamObject, PuntGeometrie):
    """Een elastisch of flexibel element is een onderdeel van een mechanische koppeling en zorgt voor het dempen van trillingen en schokken. Het wordt meestal tussen twee naven geplaatst."""

    typeURI = 'https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#ElastischElement'
    """De URI van het object volgens https://www.w3.org/2001/XMLSchema#anyURI."""

    _VALID_RELATIONS: ClassVar[list[tuple[str, str, str, str | None]]] = [
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Bevestiging', 'https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Naaf', 'u', None),  # u = unidirectional
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#HoortBij', 'https://wegenenverkeer.data.vlaanderen.be/ns/installatie#Koppeling', 'o', None),  # o = direction: outgoing
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Omhult', 'https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Huls', 'i', None),  # i = direction: incoming
    ]

    def __init__(self):
        super().__init__()

        self.add_valid_relations(self._VALID_RELATIONS)

        self._hardheid = OTLAttribuut(field=KlElastischElementHardheid,
                                      naam='hardheid',
                                      label='hardheid',
                                      objectUri='https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#ElastischElement.hardheid',
                                      definition='De hardheid van het elastisch element.',
                                      owner=self)

        self._materiaal = OTLAttribuut(field=KlElastischElementMateriaal,
                                       naam='materiaal',
                                       label='materiaal',
                                       objectUri='https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#ElastischElement.materiaal',
                                       definition='Het materiaal waaruit het elastisch element vervaardigd is.',
                                       owner=self)

    @property
    def hardheid(self) -> str:
        """De hardheid van het elastisch element."""
        return self._hardheid.get_waarde()

    @hardheid.setter
    def hardheid(self, value):
        self._hardheid.set_waarde(value, owner=self)

    @property
    def materiaal(self) -> str:
        """Het materiaal waaruit het elastisch element vervaardigd is."""
        return self._materiaal.get_waarde()

    @materiaal.setter
    def materiaal(self, value):
        self._materiaal.set_waarde(value, owner=self)
