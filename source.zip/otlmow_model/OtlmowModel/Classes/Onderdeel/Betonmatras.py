# coding=utf-8
from typing import ClassVar

from ...BaseClasses.OTLObject import OTLAttribuut
from ...Classes.Abstracten.AndereLaag import AndereLaag
from ...Classes.Abstracten.ElementSpecificatie import ElementSpecificatie
from ...Datatypes.KlSoortVoegmateriaal import KlSoortVoegmateriaal


# Generated with OTLClassCreator. To modify: extend, do not edit
class Betonmatras(AndereLaag, ElementSpecificatie):
    """De betonmatras is een specifieke vorm van een bodembescherming die bestaat uit een geotextiel gevuld met beton."""

    typeURI = 'https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Betonmatras'
    """De URI van het object volgens https://www.w3.org/2001/XMLSchema#anyURI."""

    _VALID_RELATIONS: ClassVar[list[tuple[str, str, str, str | None]]] = [
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Bevestiging', 'https://wegenenverkeer.data.vlaanderen.be/ns/abstracten#Fundering', 'u', None),  # u = unidirectional
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Bevestiging', 'https://wegenenverkeer.data.vlaanderen.be/ns/abstracten#Markering', 'u', None),  # u = unidirectional
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Bevestiging', 'https://wegenenverkeer.data.vlaanderen.be/ns/abstracten#SelNietSelLus', 'u', None),  # u = unidirectional
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Bevestiging', 'https://wegenenverkeer.data.vlaanderen.be/ns/abstracten#Straatmeubilair', 'u', None),  # u = unidirectional
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#HoortBij', 'https://wegenenverkeer.data.vlaanderen.be/ns/installatie#Bodembescherming', 'o', None),  # o = direction: outgoing
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#LigtOp', 'https://wegenenverkeer.data.vlaanderen.be/ns/abstracten#BegroeidVoorkomen', 'i', None),  # i = direction: incoming
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#LigtOp', 'https://wegenenverkeer.data.vlaanderen.be/ns/abstracten#Hoppinzuil', 'i', None),  # i = direction: incoming
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#LigtOp', 'https://wegenenverkeer.data.vlaanderen.be/ns/abstracten#Laag', 'i', None),  # i = direction: incoming
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#LigtOp', 'https://wegenenverkeer.data.vlaanderen.be/ns/abstracten#LijnvormigElement', 'i', None),  # i = direction: incoming
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#LigtOp', 'https://wegenenverkeer.data.vlaanderen.be/ns/abstracten#VegetatieElement', 'i', None),  # i = direction: incoming
    ]

    def __init__(self):
        super().__init__()

        self.add_valid_relations(self._VALID_RELATIONS)

        self._voegmateriaal = OTLAttribuut(field=KlSoortVoegmateriaal,
                                           naam='voegmateriaal',
                                           label='voegmateriaal',
                                           objectUri='https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Betonmatras.voegmateriaal',
                                           definition='De verschillende mogelijkheden voor materiaal dat wordt gebruikt voor de voegen',
                                           owner=self)

    @property
    def voegmateriaal(self) -> str:
        """De verschillende mogelijkheden voor materiaal dat wordt gebruikt voor de voegen"""
        return self._voegmateriaal.get_waarde()

    @voegmateriaal.setter
    def voegmateriaal(self, value):
        self._voegmateriaal.set_waarde(value, owner=self)
