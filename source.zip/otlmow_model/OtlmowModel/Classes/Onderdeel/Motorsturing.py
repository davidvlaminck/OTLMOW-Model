# coding=utf-8
from typing import ClassVar

from ...BaseClasses.OTLObject import OTLAttribuut
from ...Classes.Abstracten.ElektrischComponentennummerObject import (
    ElektrischComponentennummerObject,
)
from ...Classes.Abstracten.MotorVermogenskring import MotorVermogenskring
from ...Classes.Abstracten.SerienummerObject import SerienummerObject
from ...Classes.ImplementatieElement.AIMNaamObject import AIMNaamObject
from ...Datatypes.KlMotorsturingMerk import KlMotorsturingMerk
from ...Datatypes.KlMotorsturingModelnaam import KlMotorsturingModelnaam
from ...Datatypes.KlMotorsturingType import KlMotorsturingType


# Generated with OTLClassCreator. To modify: extend, do not edit
class Motorsturing(ElektrischComponentennummerObject, MotorVermogenskring, SerienummerObject, AIMNaamObject):
    """Type voor verschillende technieken voor de aansturing van de snelheid (toerental) van een motor."""

    typeURI = 'https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Motorsturing'
    """De URI van het object volgens https://www.w3.org/2001/XMLSchema#anyURI."""

    _VALID_RELATIONS: ClassVar[list[tuple[str, str, str, str | None]]] = [
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Sturing', 'https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#IOKaart', 'u', None),  # u = unidirectional
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#VoedtAangestuurd', 'https://wegenenverkeer.data.vlaanderen.be/ns/abstracten#MotorVermogenskring', 'i', None),  # i = direction: incoming
    ]

    def __init__(self):
        super().__init__()

        self.add_valid_relations(self._VALID_RELATIONS)

        self._merk = OTLAttribuut(field=KlMotorsturingMerk,
                                  naam='merk',
                                  label='merk',
                                  objectUri='https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Motorsturing.merk',
                                  definition='Merk van het DC motorsturing component volgens de fabrikant.',
                                  owner=self)

        self._modelnaam = OTLAttribuut(field=KlMotorsturingModelnaam,
                                       naam='modelnaam',
                                       label='modelnaam',
                                       objectUri='https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Motorsturing.modelnaam',
                                       definition='Naam die de fabrikant zelf geeft aan het model of de uitvoering van het DC motorsturing component.',
                                       owner=self)

        self._type = OTLAttribuut(field=KlMotorsturingType,
                                  naam='type',
                                  label='type',
                                  objectUri='https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Motorsturing.type',
                                  definition='Type van de motorsturing volgens de techniek voor aansturing van de gekoppelde motor.',
                                  owner=self)

    @property
    def merk(self) -> str:
        """Merk van het DC motorsturing component volgens de fabrikant."""
        return self._merk.get_waarde()

    @merk.setter
    def merk(self, value):
        self._merk.set_waarde(value, owner=self)

    @property
    def modelnaam(self) -> str:
        """Naam die de fabrikant zelf geeft aan het model of de uitvoering van het DC motorsturing component."""
        return self._modelnaam.get_waarde()

    @modelnaam.setter
    def modelnaam(self, value):
        self._modelnaam.set_waarde(value, owner=self)

    def _get_type(self) -> str:
        """Type van de motorsturing volgens de techniek voor aansturing van de gekoppelde motor."""
        return self._type.get_waarde()

    def _set_type(self, value):
        self._type.set_waarde(value, owner=self)
    type = property(_get_type, _set_type)
