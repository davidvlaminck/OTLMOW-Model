# coding=utf-8
from ...BaseClasses.OTLObject import OTLAttribuut
from ...Classes.Abstracten.StaalsoortObject import StaalsoortObject
from ...Classes.Abstracten.TechnischDocument import TechnischDocument
from ...Classes.ImplementatieElement.AIMNaamObject import AIMNaamObject
from ...BaseClasses.BooleanField import BooleanField
from ...GeometrieTypes.PuntGeometrie import PuntGeometrie


# Generated with OTLClassCreator. To modify: extend, do not edit
class Cilinderbodem(StaalsoortObject, TechnischDocument, AIMNaamObject, PuntGeometrie):
    """Het onderdeel dat zich aan het achtereinde van de cilindermantel bevindt om de cilinder af te sluiten."""

    typeURI = 'https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Cilinderbodem'
    """De URI van het object volgens https://www.w3.org/2001/XMLSchema#anyURI."""

    def __init__(self):
        super().__init__()

        self.add_valid_relation(relation='https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Bevestiging', target='https://wegenenverkeer.data.vlaanderen.be/ns/abstracten#Lager', direction='u')  # u = unidirectional
        self.add_valid_relation(relation='https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Bevestiging', target='https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Cilindermantel', direction='u')  # u = unidirectional
        self.add_valid_relation(relation='https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#HoortBij', target='https://wegenenverkeer.data.vlaanderen.be/ns/abstracten#Cilindermechanisme', direction='o')  # o = direction: outgoing

        self._isOog = OTLAttribuut(field=BooleanField,
                                   naam='isOog',
                                   label='is oog',
                                   objectUri='https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Cilinderbodem.isOog',
                                   definition='Geeft aan of de cilinderbodem uitgevoerd is als oog. In zo een geval wordt de cilinderbodem tussen een gaffel geschoven. In het andere geval is de cilinderbodem zelf een gaffel dat over een oog wordt geschoven.',
                                   owner=self)

    @property
    def isOog(self) -> bool:
        """Geeft aan of de cilinderbodem uitgevoerd is als oog. In zo een geval wordt de cilinderbodem tussen een gaffel geschoven. In het andere geval is de cilinderbodem zelf een gaffel dat over een oog wordt geschoven."""
        return self._isOog.get_waarde()

    @isOog.setter
    def isOog(self, value):
        self._isOog.set_waarde(value, owner=self)
