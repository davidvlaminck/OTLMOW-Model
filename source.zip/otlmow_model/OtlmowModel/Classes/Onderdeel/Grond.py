# coding=utf-8
from typing import ClassVar

from ...BaseClasses.NonNegIntegerField import NonNegIntegerField
from ...BaseClasses.OTLObject import OTLAttribuut
from ...Classes.Abstracten.Laag import Laag
from ...Classes.Abstracten.LaagDikte import LaagDikte
from ...Datatypes.DtcDocument import DtcDocument, DtcDocumentWaarden
from ...Datatypes.DtcGrondsoort import DtcGrondsoort, DtcGrondsoortWaarden
from ...Datatypes.DtcSoortVervuiling import (
    DtcSoortVervuiling,
    DtcSoortVervuilingWaarden,
)
from ...Datatypes.KwantWrdInMeter import KwantWrdInMeter, KwantWrdInMeterWaarden


# Generated with OTLClassCreator. To modify: extend, do not edit
class Grond(Laag, LaagDikte):
    """Lithologisch hoofd- en nevenbestanddeel (als code) van de laag zoals gebruikt bij Databank Ondergrond Vlaanderen (gecodeerde lithologie en geotechnische codering)."""

    typeURI = 'https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Grond'
    """De URI van het object volgens https://www.w3.org/2001/XMLSchema#anyURI."""

    _VALID_RELATIONS: ClassVar[list[tuple[str, str, str, str | None]]] = [
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Bevestiging', 'https://wegenenverkeer.data.vlaanderen.be/ns/abstracten#Fundering', 'u', None),  # u = unidirectional
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Bevestiging', 'https://wegenenverkeer.data.vlaanderen.be/ns/abstracten#Markering', 'u', None),  # u = unidirectional
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Bevestiging', 'https://wegenenverkeer.data.vlaanderen.be/ns/abstracten#SelNietSelLus', 'u', None),  # u = unidirectional
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Bevestiging', 'https://wegenenverkeer.data.vlaanderen.be/ns/abstracten#Straatmeubilair', 'u', None),  # u = unidirectional
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Bevestiging', 'https://wegenenverkeer.data.vlaanderen.be/ns/installatie#Damwand', 'u', None),  # u = unidirectional
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Bevestiging', 'https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#PiezometrischeBuis', 'u', None),  # u = unidirectional
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#HeeftBeheer', 'https://wegenenverkeer.data.vlaanderen.be/ns/levenscyclus#Afdekking', 'o', None),  # o = direction: outgoing
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#HeeftBeheer', 'https://wegenenverkeer.data.vlaanderen.be/ns/levenscyclus#Afgraving', 'o', None),  # o = direction: outgoing
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#HeeftBeheer', 'https://wegenenverkeer.data.vlaanderen.be/ns/levenscyclus#Bemesting', 'o', None),  # o = direction: outgoing
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#HeeftBeheer', 'https://wegenenverkeer.data.vlaanderen.be/ns/levenscyclus#Bodemverbeteringsmiddel', 'o', None),  # o = direction: outgoing
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#HeeftBeheer', 'https://wegenenverkeer.data.vlaanderen.be/ns/levenscyclus#Grondbewerking', 'o', None),  # o = direction: outgoing
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#HeeftBeheer', 'https://wegenenverkeer.data.vlaanderen.be/ns/levenscyclus#Ophoging', 'o', None),  # o = direction: outgoing
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#HeeftBeheer', 'https://wegenenverkeer.data.vlaanderen.be/ns/levenscyclus#Uitgraving', 'o', None),  # o = direction: outgoing
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#IsInspectieVan', 'https://wegenenverkeer.data.vlaanderen.be/ns/proefenmeting#ProefBindmiddeldosering', 'i', None),  # i = direction: incoming
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#LigtOp', 'https://wegenenverkeer.data.vlaanderen.be/ns/abstracten#BegroeidVoorkomen', 'i', None),  # i = direction: incoming
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#LigtOp', 'https://wegenenverkeer.data.vlaanderen.be/ns/abstracten#Hoppinzuil', 'i', None),  # i = direction: incoming
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#LigtOp', 'https://wegenenverkeer.data.vlaanderen.be/ns/abstracten#Laag', 'i', None),  # i = direction: incoming
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#LigtOp', 'https://wegenenverkeer.data.vlaanderen.be/ns/abstracten#LijnvormigElement', 'i', None),  # i = direction: incoming
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#LigtOp', 'https://wegenenverkeer.data.vlaanderen.be/ns/abstracten#VegetatieElement', 'i', None),  # i = direction: incoming
    ]

    def __init__(self):
        super().__init__()

        self.add_valid_relations(self._VALID_RELATIONS)

        self._grondsoort = OTLAttribuut(field=DtcGrondsoort,
                                        naam='grondsoort',
                                        label='soort grond',
                                        objectUri='https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Grond.grondsoort',
                                        definition='Lithologisch hoofd- en nevenbestanddeel (als code) van de laag zoals gebruikt bij databank ondergrond Vlaanderen (gecodeerde lithologie en geotechnische codering).',
                                        owner=self)

        self._milieuHygienischeCode = OTLAttribuut(field=NonNegIntegerField,
                                                   naam='milieuHygienischeCode',
                                                   label='milieuhygiënische code',
                                                   objectUri='https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Grond.milieuHygienischeCode',
                                                   definition='Het 3-delig nummer dat gehanteerd wordt door de vzw grondbank om de milieuhygiënische mogelijkheden van een partij bodem of grond aan te geven.',
                                                   owner=self)

        self._soortVervuiling = OTLAttribuut(field=DtcSoortVervuiling,
                                             naam='soortVervuiling',
                                             label='soort vervuiling',
                                             objectUri='https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Grond.soortVervuiling',
                                             definition='De soort vervuiling die vastgesteld is op het pakket grond.',
                                             owner=self)

        self._technischVerslagBodemonderzoek = OTLAttribuut(field=DtcDocument,
                                                            naam='technischVerslagBodemonderzoek',
                                                            label='technisch verslag bodemonderzoek',
                                                            objectUri='https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Grond.technischVerslagBodemonderzoek',
                                                            kardinaliteit_max='*',
                                                            definition='Het technisch verslag van een bodemonderzoek.',
                                                            owner=self)

        self._tot = OTLAttribuut(field=KwantWrdInMeter,
                                 naam='tot',
                                 label='tot',
                                 objectUri='https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Grond.tot',
                                 definition='Diepte van de onderkant van de laag in meter. https://www.dov.vlaanderen.be/xdov/schema/latest/xsd/kern/generiek/GeneriekeDataTypes.xsd (DiepteType).',
                                 owner=self)

        self._van = OTLAttribuut(field=KwantWrdInMeter,
                                 naam='van',
                                 label='van',
                                 objectUri='https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Grond.van',
                                 definition='Diepte van de bovenkant van de laag in meter. https://www.dov.vlaanderen.be/xdov/schema/latest/xsd/kern/generiek/GeneriekeDataTypes.xsd (DiepteType).',
                                 owner=self)

    @property
    def grondsoort(self) -> DtcGrondsoortWaarden:
        """Lithologisch hoofd- en nevenbestanddeel (als code) van de laag zoals gebruikt bij databank ondergrond Vlaanderen (gecodeerde lithologie en geotechnische codering)."""
        return self._grondsoort.get_waarde()

    @grondsoort.setter
    def grondsoort(self, value):
        self._grondsoort.set_waarde(value, owner=self)

    @property
    def milieuHygienischeCode(self) -> int:
        """Het 3-delig nummer dat gehanteerd wordt door de vzw grondbank om de milieuhygiënische mogelijkheden van een partij bodem of grond aan te geven."""
        return self._milieuHygienischeCode.get_waarde()

    @milieuHygienischeCode.setter
    def milieuHygienischeCode(self, value):
        self._milieuHygienischeCode.set_waarde(value, owner=self)

    @property
    def soortVervuiling(self) -> DtcSoortVervuilingWaarden:
        """De soort vervuiling die vastgesteld is op het pakket grond."""
        return self._soortVervuiling.get_waarde()

    @soortVervuiling.setter
    def soortVervuiling(self, value):
        self._soortVervuiling.set_waarde(value, owner=self)

    @property
    def technischVerslagBodemonderzoek(self) -> list[DtcDocumentWaarden]:
        """Het technisch verslag van een bodemonderzoek."""
        return self._technischVerslagBodemonderzoek.get_waarde()

    @technischVerslagBodemonderzoek.setter
    def technischVerslagBodemonderzoek(self, value):
        self._technischVerslagBodemonderzoek.set_waarde(value, owner=self)

    @property
    def tot(self) -> KwantWrdInMeterWaarden:
        """Diepte van de onderkant van de laag in meter. https://www.dov.vlaanderen.be/xdov/schema/latest/xsd/kern/generiek/GeneriekeDataTypes.xsd (DiepteType)."""
        return self._tot.get_waarde()

    @tot.setter
    def tot(self, value):
        self._tot.set_waarde(value, owner=self)

    @property
    def van(self) -> KwantWrdInMeterWaarden:
        """Diepte van de bovenkant van de laag in meter. https://www.dov.vlaanderen.be/xdov/schema/latest/xsd/kern/generiek/GeneriekeDataTypes.xsd (DiepteType)."""
        return self._van.get_waarde()

    @van.setter
    def van(self, value):
        self._van.set_waarde(value, owner=self)
