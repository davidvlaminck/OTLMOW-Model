# coding=utf-8
from typing import ClassVar

from ...BaseClasses.OTLObject import OTLAttribuut
from ...Classes.ImplementatieElement.AIMNaamObject import AIMNaamObject
from ...Datatypes.KwantWrdInMeterTAW import (
    KwantWrdInMeterTAW,
    KwantWrdInMeterTAWWaarden,
)
from ...Datatypes.KwantWrdInMillimeter import (
    KwantWrdInMillimeter,
    KwantWrdInMillimeterWaarden,
)
from ...GeometrieTypes.LijnGeometrie import LijnGeometrie


# Generated with OTLClassCreator. To modify: extend, do not edit
class Stuwconstructie(AIMNaamObject, LijnGeometrie):
    """Een debietbegrenzende constructie waarbij de afvoer van water gebeurt al dan niet via een knijpopening of een andere hydraulische beperking. Bij hevige regenval, wanneer de watertoevoer niet meer kan worden verwerkt, wordt buffering opgebouwd tot aan de overstort."""

    typeURI = 'https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Stuwconstructie'
    """De URI van het object volgens https://www.w3.org/2001/XMLSchema#anyURI."""

    _VALID_RELATIONS: ClassVar[list[tuple[str, str, str, str | None]]] = [
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#SluitAanOp', 'https://wegenenverkeer.data.vlaanderen.be/ns/abstracten#WaterloopRelatie', 'i', None),  # i = direction: incoming
        ('https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#SluitAanOp', 'https://wegenenverkeer.data.vlaanderen.be/ns/abstracten#WaterloopRelatie', 'o', None),  # o = direction: outgoing
    ]

    def __init__(self):
        super().__init__()

        self.add_valid_relations(self._VALID_RELATIONS)

        self._breedteUitsparing = OTLAttribuut(field=KwantWrdInMillimeter,
                                               naam='breedteUitsparing',
                                               label='breedte uitsparing',
                                               objectUri='https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Stuwconstructie.breedteUitsparing',
                                               usagenote='Indien er geen uitsparing aanwezig is, is deze waarde 0.',
                                               definition='De breedte van het uitgesneden deel dat de functie heeft van overstort in millimeter.',
                                               owner=self)

        self._diameterKnijpopening = OTLAttribuut(field=KwantWrdInMillimeter,
                                                  naam='diameterKnijpopening',
                                                  label='diameter knijpopening',
                                                  objectUri='https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Stuwconstructie.diameterKnijpopening',
                                                  usagenote='Indien er geen knijpopening aanwezig is, is deze waarde 0.',
                                                  definition='De diameter van de opening onderaan de cascade die zorgt voor een vertraagde waterafvoer bij hevige regenval of overvloedige toevoer van water in millimeter.',
                                                  owner=self)

        self._overstortpeil = OTLAttribuut(field=KwantWrdInMeterTAW,
                                           naam='overstortpeil',
                                           label='overstortpeil',
                                           objectUri='https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#Stuwconstructie.overstortpeil',
                                           definition='Drempelpeil van de overstort. Uitgedrukt in meter-TAW gemeten in het midden van de drempel.',
                                           owner=self)

    @property
    def breedteUitsparing(self) -> KwantWrdInMillimeterWaarden:
        """De breedte van het uitgesneden deel dat de functie heeft van overstort in millimeter."""
        return self._breedteUitsparing.get_waarde()

    @breedteUitsparing.setter
    def breedteUitsparing(self, value):
        self._breedteUitsparing.set_waarde(value, owner=self)

    @property
    def diameterKnijpopening(self) -> KwantWrdInMillimeterWaarden:
        """De diameter van de opening onderaan de cascade die zorgt voor een vertraagde waterafvoer bij hevige regenval of overvloedige toevoer van water in millimeter."""
        return self._diameterKnijpopening.get_waarde()

    @diameterKnijpopening.setter
    def diameterKnijpopening(self, value):
        self._diameterKnijpopening.set_waarde(value, owner=self)

    @property
    def overstortpeil(self) -> KwantWrdInMeterTAWWaarden:
        """Drempelpeil van de overstort. Uitgedrukt in meter-TAW gemeten in het midden van de drempel."""
        return self._overstortpeil.get_waarde()

    @overstortpeil.setter
    def overstortpeil(self, value):
        self._overstortpeil.set_waarde(value, owner=self)
