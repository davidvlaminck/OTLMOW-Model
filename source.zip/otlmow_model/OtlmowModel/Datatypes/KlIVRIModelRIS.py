# coding=utf-8
from ..BaseClasses.KeuzelijstField import KeuzelijstField
from ..BaseClasses.KeuzelijstWaarde import KeuzelijstWaarde


# Generated with OTLEnumerationCreator. To modify: extend, do not edit
class KlIVRIModelRIS(KeuzelijstField):
    """De modelnaam van de RIS."""
    naam = 'KlIVRIModelRIS'
    label = 'iVRIModelRIS'
    objectUri = 'https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#KlIVRIModelRIS'
    definition = 'De modelnaam van de RIS.'
    status = 'ingebruik'
    codelist = 'https://wegenenverkeer.data.vlaanderen.be/id/conceptscheme/KlIVRIModelRIS'
    options = {
        'cloudris': KeuzelijstWaarde(invulwaarde='cloudris',
                                     label='CloudRIS',
                                     status='ingebruik',
                                     definitie='CloudRIS',
                                     objectUri='https://wegenenverkeer.data.vlaanderen.be/id/concept/KlIVRIModelRIS/cloudris'),
        'stridefx': KeuzelijstWaarde(invulwaarde='stridefx',
                                     label='StrideFX',
                                     status='ingebruik',
                                     definitie='StrideFX',
                                     objectUri='https://wegenenverkeer.data.vlaanderen.be/id/concept/KlIVRIModelRIS/stridefx'),
        'virtualacu': KeuzelijstWaarde(invulwaarde='virtualacu',
                                       label='VirtualACU',
                                       status='ingebruik',
                                       definitie='VirtualACU',
                                       objectUri='https://wegenenverkeer.data.vlaanderen.be/id/concept/KlIVRIModelRIS/virtualacu')
    }

    @classmethod
    def create_dummy_data(cls):
        return cls.create_dummy_data_keuzelijst(cls.options)

