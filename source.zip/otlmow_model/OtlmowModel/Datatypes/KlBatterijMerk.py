# coding=utf-8
from ..BaseClasses.KeuzelijstField import KeuzelijstField
from ..BaseClasses.KeuzelijstWaarde import KeuzelijstWaarde


# Generated with OTLEnumerationCreator. To modify: extend, do not edit
class KlBatterijMerk(KeuzelijstField):
    """Het merk van de batterij."""
    naam = 'KlBatterijMerk'
    label = 'Batterij merk'
    objectUri = 'https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#KlBatterijMerk'
    definition = 'Het merk van de batterij.'
    status = 'ingebruik'
    codelist = 'https://wegenenverkeer.data.vlaanderen.be/id/conceptscheme/KlBatterijMerk'
    options = {
        'eco-counter': KeuzelijstWaarde(invulwaarde='eco-counter',
                                        label='eco-counter',
                                        status='ingebruik',
                                        definitie='eco-counter',
                                        objectUri='https://wegenenverkeer.data.vlaanderen.be/id/concept/KlBatterijMerk/eco-counter'),
        'landport': KeuzelijstWaarde(invulwaarde='landport',
                                     label='landport',
                                     status='ingebruik',
                                     definitie='landport',
                                     objectUri='https://wegenenverkeer.data.vlaanderen.be/id/concept/KlBatterijMerk/landport'),
        'marathon': KeuzelijstWaarde(invulwaarde='marathon',
                                     label='Marathon',
                                     status='ingebruik',
                                     definitie='Marathon Powercycle',
                                     objectUri='https://wegenenverkeer.data.vlaanderen.be/id/concept/KlBatterijMerk/marathon'),
        'pbq': KeuzelijstWaarde(invulwaarde='pbq',
                                label='pbq',
                                status='ingebruik',
                                definitie='pbq',
                                objectUri='https://wegenenverkeer.data.vlaanderen.be/id/concept/KlBatterijMerk/pbq'),
        'yuasa': KeuzelijstWaarde(invulwaarde='yuasa',
                                  label='yuasa',
                                  status='ingebruik',
                                  definitie='yuasa',
                                  objectUri='https://wegenenverkeer.data.vlaanderen.be/id/concept/KlBatterijMerk/yuasa')
    }

    @classmethod
    def create_dummy_data(cls):
        return cls.create_dummy_data_keuzelijst(cls.options)

