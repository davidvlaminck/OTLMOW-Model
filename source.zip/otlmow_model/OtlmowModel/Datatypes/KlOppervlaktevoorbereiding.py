# coding=utf-8
from ..BaseClasses.KeuzelijstField import KeuzelijstField


# Generated with OTLEnumerationCreator. To modify: extend, do not edit
class KlOppervlaktevoorbereiding(KeuzelijstField):
    """De mogelijke oppverlaktevoorbereidingen."""
    naam = 'KlOppervlaktevoorbereiding'
    label = 'Oppervlaktevoorbereiding'
    objectUri = 'https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#KlOppervlaktevoorbereiding'
    definition = 'De mogelijke oppverlaktevoorbereidingen.'
    status = 'ingebruik'
    codelist = 'https://wegenenverkeer.data.vlaanderen.be/id/conceptscheme/KlOppervlaktevoorbereiding'
    options = {
    }

    @classmethod
    def create_dummy_data(cls):
        return cls.create_dummy_data_keuzelijst(cls.options)

