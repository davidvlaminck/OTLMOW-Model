# coding=utf-8
from ..BaseClasses.KeuzelijstField import KeuzelijstField
from ..BaseClasses.KeuzelijstWaarde import KeuzelijstWaarde


# Generated with OTLEnumerationCreator. To modify: extend, do not edit
class KlPompMerk(KeuzelijstField):
    """Lijst met merknamen voor pompen."""
    naam = 'KlPompMerk'
    label = 'Typepomp merk'
    objectUri = 'https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#KlPompMerk'
    definition = 'Lijst met merknamen voor pompen.'
    status = 'ingebruik'
    codelist = 'https://wegenenverkeer.data.vlaanderen.be/id/conceptscheme/KlPompMerk'
    options = {
        'aspen-pumps': KeuzelijstWaarde(invulwaarde='aspen-pumps',
                                        label='Aspen Pumps',
                                        status='ingebruik',
                                        definitie='Aspen Pumps',
                                        objectUri='https://wegenenverkeer.data.vlaanderen.be/id/concept/KlPompMerk/aspen-pumps'),
        'flygt': KeuzelijstWaarde(invulwaarde='flygt',
                                  label='Flygt',
                                  status='ingebruik',
                                  definitie='Flygt',
                                  objectUri='https://wegenenverkeer.data.vlaanderen.be/id/concept/KlPompMerk/flygt'),
        'lowara': KeuzelijstWaarde(invulwaarde='lowara',
                                   label='Lowara',
                                   status='ingebruik',
                                   definitie='LOWARA',
                                   objectUri='https://wegenenverkeer.data.vlaanderen.be/id/concept/KlPompMerk/lowara'),
        'xylem': KeuzelijstWaarde(invulwaarde='xylem',
                                  label='Xylem',
                                  status='ingebruik',
                                  definitie='Xylem',
                                  objectUri='https://wegenenverkeer.data.vlaanderen.be/id/concept/KlPompMerk/xylem')
    }

    @classmethod
    def create_dummy_data(cls):
        return cls.create_dummy_data_keuzelijst(cls.options)

