# coding=utf-8
from ..BaseClasses.KeuzelijstField import KeuzelijstField


# Generated with OTLEnumerationCreator. To modify: extend, do not edit
class KlMateriaalStalenKlemblok(KeuzelijstField):
    """De keuzelijst van de opties van materialen voor het stalen klemblok van het klemsysteem."""
    naam = 'KlMateriaalStalenKlemblok'
    label = 'Het materiaal van het stalen klemblok'
    objectUri = 'https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#KlMateriaalStalenKlemblok'
    definition = 'De keuzelijst van de opties van materialen voor het stalen klemblok van het klemsysteem.'
    status = 'ingebruik'
    codelist = 'https://wegenenverkeer.data.vlaanderen.be/id/conceptscheme/KlMateriaalStalenKlemblok'
    options = {
    }

    @classmethod
    def create_dummy_data(cls):
        return cls.create_dummy_data_keuzelijst(cls.options)

