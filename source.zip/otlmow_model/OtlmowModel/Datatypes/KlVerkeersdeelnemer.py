# coding=utf-8
from otlmow_model.OtlmowModel.BaseClasses.KeuzelijstField import KeuzelijstField


# Generated with OTLEnumerationCreator. To modify: extend, do not edit
class KlVerkeersdeelnemer(KeuzelijstField):
    """De mogelijke entiteiten die deelnemen aan het verkeer."""
    naam = 'KlVerkeersdeelnemer'
    label = 'Verkeersdeelnemer'
    objectUri = 'https://wegenenverkeer.data.vlaanderen.be/ns/onderdeel#KlVerkeersdeelnemer'
    definition = 'De mogelijke entiteiten die deelnemen aan het verkeer.'
    status = 'ingebruik'
    codelist = 'https://wegenenverkeer.data.vlaanderen.be/id/conceptscheme/KlVerkeersdeelnemer'
    options = {
    }

    @classmethod
    def create_dummy_data(cls):
        return cls.create_dummy_data_keuzelijst(cls.options)

