# coding=utf-8
from ..BaseClasses.KeuzelijstField import KeuzelijstField
from ..BaseClasses.KeuzelijstWaarde import KeuzelijstWaarde


# Generated with OTLEnumerationCreator. To modify: extend, do not edit
class KlBijlageType(KeuzelijstField):
    """De mogelijke types of categorieën van het document."""
    naam = 'KlBijlageType'
    label = 'Bijlage type'
    objectUri = 'https://wegenenverkeer.data.vlaanderen.be/ns/implementatieelement#KlBijlageType'
    definition = 'De mogelijke types of categorieën van het document.'
    status = 'ingebruik'
    codelist = 'https://wegenenverkeer.data.vlaanderen.be/id/conceptscheme/KlBijlageType'
    options = {
        'attest': KeuzelijstWaarde(invulwaarde='attest',
                                   label='attest',
                                   status='ingebruik',
                                   definitie='attest',
                                   objectUri='https://wegenenverkeer.data.vlaanderen.be/id/concept/KlBijlageType/attest'),
        'berekeningsnota': KeuzelijstWaarde(invulwaarde='berekeningsnota',
                                            label='berekeningsnota',
                                            status='ingebruik',
                                            definitie='berekeningsnota',
                                            objectUri='https://wegenenverkeer.data.vlaanderen.be/id/concept/KlBijlageType/berekeningsnota'),
        'elektrisch-schema': KeuzelijstWaarde(invulwaarde='elektrisch-schema',
                                              label='elektrisch schema',
                                              status='ingebruik',
                                              definitie='elektrisch schema',
                                              objectUri='https://wegenenverkeer.data.vlaanderen.be/id/concept/KlBijlageType/elektrisch-schema'),
        'foto': KeuzelijstWaarde(invulwaarde='foto',
                                 label='foto',
                                 status='ingebruik',
                                 definitie='foto',
                                 objectUri='https://wegenenverkeer.data.vlaanderen.be/id/concept/KlBijlageType/foto'),
        'handleiding': KeuzelijstWaarde(invulwaarde='handleiding',
                                        label='handleiding',
                                        status='ingebruik',
                                        definitie='handleiding',
                                        objectUri='https://wegenenverkeer.data.vlaanderen.be/id/concept/KlBijlageType/handleiding'),
        'oproepdocument': KeuzelijstWaarde(invulwaarde='oproepdocument',
                                           label='oproepdocument',
                                           status='ingebruik',
                                           definitie='oproepdocument',
                                           objectUri='https://wegenenverkeer.data.vlaanderen.be/id/concept/KlBijlageType/oproepdocument'),
        'plan': KeuzelijstWaarde(invulwaarde='plan',
                                 label='plan',
                                 status='ingebruik',
                                 definitie='plan',
                                 objectUri='https://wegenenverkeer.data.vlaanderen.be/id/concept/KlBijlageType/plan'),
        'risicoanalyse': KeuzelijstWaarde(invulwaarde='risicoanalyse',
                                          label='risicoanalyse',
                                          status='ingebruik',
                                          definitie='risicoanalyse',
                                          objectUri='https://wegenenverkeer.data.vlaanderen.be/id/concept/KlBijlageType/risicoanalyse'),
        'technische-fiche': KeuzelijstWaarde(invulwaarde='technische-fiche',
                                             label='technische fiche',
                                             status='uitgebruik',
                                             definitie='technische fiche',
                                             objectUri='https://wegenenverkeer.data.vlaanderen.be/id/concept/KlBijlageType/technische-fiche'),
        'verslag': KeuzelijstWaarde(invulwaarde='verslag',
                                    label='verslag',
                                    status='ingebruik',
                                    definitie='verslag',
                                    objectUri='https://wegenenverkeer.data.vlaanderen.be/id/concept/KlBijlageType/verslag')
    }

    @classmethod
    def create_dummy_data(cls):
        return cls.create_dummy_data_keuzelijst(cls.options)

