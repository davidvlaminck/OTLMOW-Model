class CanNotClearAttributeError(Exception):
    pass
