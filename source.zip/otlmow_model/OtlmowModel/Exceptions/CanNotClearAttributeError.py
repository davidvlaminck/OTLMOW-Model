class CanNotClearAttributeError(Exception):
    pass