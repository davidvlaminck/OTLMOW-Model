class MethodNotApplicableError(Exception):
    pass
