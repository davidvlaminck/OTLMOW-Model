class WrongGeometryTypeError(Exception):
    pass
