import logging


class NonStandardAttributeWarning(Warning):
    def __init__(self, msg):
        pass
