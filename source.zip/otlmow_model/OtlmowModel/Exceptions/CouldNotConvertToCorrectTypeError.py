﻿class CouldNotConvertToCorrectTypeError(Exception):
    pass