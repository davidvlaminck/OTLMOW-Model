class CouldNotConvertToCorrectTypeError(Exception):
    pass
