﻿class UnionTypeError(ValueError):
    pass