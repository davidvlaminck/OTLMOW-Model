class UnionTypeError(ValueError):
    pass
