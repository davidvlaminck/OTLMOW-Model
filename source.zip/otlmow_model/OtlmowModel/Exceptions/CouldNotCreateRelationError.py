class CouldNotCreateRelationError(Exception):
    pass
