class RemovedOptionError(Exception):
    pass
