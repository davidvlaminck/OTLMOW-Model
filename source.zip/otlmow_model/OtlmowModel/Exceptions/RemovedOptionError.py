﻿class RemovedOptionError(Exception):
    pass